<?php
/**
 * Copyright © 2015 Magenest. All rights reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Keyexpress_ProxyDemo',
    __DIR__
);
